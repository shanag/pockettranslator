//
//  Constants.m
//  PocketTranslator
//
//  Created by Shana Golden on 5/1/11.
//  Copyright 2011 S. Golden. All rights reserved.
//

#import "Constants.h"

NSString * const GoogleAPIKey = @"AIzaSyBmjrVvtb7DJBUSeEgFMHPiqUtMpgtbPIk";
NSString * const TranslationsKey = @"translations";

// Defines constants for use in the app
@implementation Constants

@end
