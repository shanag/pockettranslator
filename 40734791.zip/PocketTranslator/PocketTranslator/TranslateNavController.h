//
//  TranslateViewController.h
//  PocketTranslator
//
//  Created by Shana Golden on 4/29/11.
//  Copyright 2011 S. Golden. All rights reserved.
//

#import <UIKit/UIKit.h>

// Navigation controller for the translate tab
@interface TranslateNavController : UINavigationController {
}


@end
