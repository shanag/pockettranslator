//
//  ViewBackgroundGradient.h
//  PocketTranslator
//
//  Created by Shana Golden on 5/1/11.
//  Copyright 2011 S. Golden. All rights reserved.
//

#import <UIKit/UIKit.h>

// Gradient background for a View
@interface ViewBackgroundGradient : UIView {
    
}

@end
