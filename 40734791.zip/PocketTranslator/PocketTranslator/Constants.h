//
//  Constants.h
//  PocketTranslator
//
//  Created by Shana Golden on 5/1/11.
//  Copyright 2011 S. Golden. All rights reserved.
//

extern NSString * const GoogleAPIKey;
extern NSString * const TranslationsKey;

// Defines constants for use in the app
@interface Constants : NSObject {

}
@end