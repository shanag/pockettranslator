//
//  SettingsNavController.h
//  PocketTranslator
//
//  Created by Shana Golden on 5/2/11.
//  Copyright 2011 S. Golden. All rights reserved.
//

#import <UIKit/UIKit.h>

// Navigation controller for the settings tab
@interface SettingsNavController : UINavigationController {
    
}

@end
