//
//  main.m
//  PocketTranslator
//
//  Created by Shana Golden on 4/29/11.
//  Apple ID is greycat92@hotmail.com
//  Copyright 2011 S. Golden. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
